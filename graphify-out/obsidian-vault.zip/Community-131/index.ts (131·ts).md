---
id: "c_users_zarny_acs_estimates_repo_src_components_layouts_pages_index_ts"
label: "index.ts"
file_type: code
community: 131
source_file: "C:\Users\zarny\acs-estimates-repo\src\components\layouts\pages\index.ts"
source_location: "L1"
---

# index.ts

**Source:** `C:\Users\zarny\acs-estimates-repo\src\components\layouts\pages\index.ts` L1
